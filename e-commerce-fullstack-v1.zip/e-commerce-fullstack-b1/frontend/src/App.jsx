import { Home } from "./modules/products/pages/Home";

const App = ()=>{
  return (<div>
        <Home/>
  </div>)
}
export default App;
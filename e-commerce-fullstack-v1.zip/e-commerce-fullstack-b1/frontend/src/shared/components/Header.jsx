import React from 'react'

export const Header = () => {
  return (
    <div>Header</div>
  )
}

import React from 'react'

export const Banner = () => {
  return (
    <div>Banner</div>
  )
}

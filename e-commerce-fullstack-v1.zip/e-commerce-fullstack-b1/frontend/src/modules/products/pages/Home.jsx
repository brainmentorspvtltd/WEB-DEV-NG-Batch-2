import { Footer } from "../../../shared/components/Footer"
import { Header } from "../../../shared/components/Header"
import { Banner } from "../components/Banner"
import { Products } from "../components/Products"

export const Home = ()=>{
    return (<div>
            <Header/>
            <Banner/>
            <p>Home Page</p>
            <Products/>
            <Footer/>
    </div>)
}
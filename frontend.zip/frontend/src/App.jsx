import Products from "./modules/products/pages/Products";


const App = ()=>{
  return (<Products/>)
}
export default App;
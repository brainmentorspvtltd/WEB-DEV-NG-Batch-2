async function getData(URL){
    console.log('URL is ', URL);
   const response =  await fetch(URL); // network call / api call
   const object  = await response.json(); // Deserialization (json to object)
   return object; 
}
export default getData;
import {useEffect, useState} from 'react';
import getData from '../../../shared/services/api-client';
import Product from '../components/Product';
const Products = ()=>{
    const [products , setProducts] = useState([]);
    // when products component is mount on screen , then make an api call
    useEffect(()=>{
        loadProducts();
    },[]);

    const loadProducts = async ()=>{
        console.log('Products ::: ', import.meta.env);
        //const products = await getData(import.meta.env.PRODUCTS_URL);
        const products = await getData('https://fakestoreapi.com/products');
        setProducts(products);
        console.log('All Products are ', products);
    }

  //  return (<h1>Products {products.length}</h1>)
  return (<div className='row'>
    {products.map(product=><Product pr = {product}/>)}
  </div>)

}
export default Products;
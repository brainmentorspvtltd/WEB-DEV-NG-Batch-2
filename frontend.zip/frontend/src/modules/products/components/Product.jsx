// Product represent single product
const Product = (props)=>{
    console.log('Props are ', props);
    const myStyle = {"width": "18rem"};
    return (<div className="card me-2" style={myStyle}>
    <img src={props.pr.image} className="card-img-top" alt="..."/>
    <div className="card-body">
      <h5 className="card-title">{props.pr.title}</h5>
      <p className="card-text">{props.pr.description.substring(0,50)}</p>
      <a href="#" className="btn btn-primary">Add to Cart</a>
    </div>
  </div>);
}
export default Product;

// What is Component?
// Component is a function , having JSX 
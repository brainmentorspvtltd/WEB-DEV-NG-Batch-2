import {createRoot} from 'react-dom/client';
import App from './App';
// React DOM Handshake b/w VDOM and DOM
const div = document.querySelector('#root'); // DOM
const root = createRoot(div);
root.render(<App/>);

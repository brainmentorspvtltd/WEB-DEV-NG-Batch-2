import React, { useState } from 'react'
import { Message } from '../components/Message'
import { Button } from '../components/Button'

export const CounterApp = () => {
   //let counter = 0; 
  // change in state
  // Hooks
  const [counter, setCounter ] = useState(0); // useState(initialValue)
   const plus = (a)=>{
    //console.log('Plus call ',a);
    //counter++;
    setCounter(counter + 1); // Immutable  (Async) - Prepare New State
    console.log('Plus ', counter); // Old State
  } 
  const minus = (b)=>{
    setCounter(counter - 1);
    console.log('Minus ', counter);
  } 
  return (
    <div className='container'>
        <Message css="alert alert-info text-center" msg = "CounterApp"/> 
        <Message css="alert alert-success" msg = "Count Value is " val = {counter}/>
        <Button fn={plus} css = 'btn btn-primary me-4' val = "+"/>
        <Button fn={minus} css = 'btn btn-success' val = "-"/>
    </div>
  )
}

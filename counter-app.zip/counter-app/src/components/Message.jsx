class A{

}
export const Message = (props)=>{
    //React.createElement('h1',{className:''}, 'Hello react js');
    return (<h1 className={props.css}>{props.msg} {props.val} </h1>)
}
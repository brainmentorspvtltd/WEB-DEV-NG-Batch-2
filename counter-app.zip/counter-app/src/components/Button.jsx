export const Button = ({val, css, fn})=>{
    // return (<button onClick={()=>{
    //     fn('Some Value Pass');
    // }}  className={css}>{val}</button>)
    return (<button onClick={fn}  className={css}>{val}</button>)
}
// Clean Code
// SRP 
// get all the songs from the backend api
export function getSongs(singerName ='Sonu Nigam'){
  //   function getSongs(singerName ='Sonu Nigam'){
    const END_POINT_URL = `https://itunes.apple.com/search?term=${singerName}&limit=25`; 
    const promise = fetch(END_POINT_URL); // Async  
    return promise;
    // Promise States
    // 1. Pending
    // 2. FullFilled, Reject  
}
// default export - one file one time, not wrap in object
//export default getSongs; 
// export will wrap the exported things in object and
// then export

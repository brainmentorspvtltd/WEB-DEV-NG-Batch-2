// Glue b/w view and data

import {getSongs} from "./api-client.js";

const promise = getSongs();
// what is response = Header (Meta) + Body (Data)
promise.then(function(response){
    const promise2 = response.json();
    promise2.then(songs=>{
        console.log('All Songs ', songs);
        printSongs(songs.results);
    }).catch(err=>{
        console.log('Invalid JSON ', err);
    })
}).catch(err=>{
    console.log('Something went wrong... ', err);
})

function printSongs(songs){
    for(var i = 0 ; i<songs.length; i++){
    printSong(songs[i]);
    }
}

function printSong(song){
    // Dynamic HTML
   const pTag =  document.createElement('p'); // <p>InnerText</p>
   pTag.innerText = song.trackName;
   const img = document.createElement('img');
   img.src = song.artworkUrl100;
   const audio = document.createElement('audio');
   audio.src = song.previewUrl;
   audio.controls = true;
   const root = document.getElementById('root');
   root.appendChild(pTag);
   root.appendChild(img);
   root.appendChild(audio);


}